package com.leaftaps.pages;

import org.openqa.selenium.WebElement;

import com.framework.selenium.api.design.Locators;
import com.framework.testng.api.base.ProjectSpecificMethods;

public class MyHomePage extends ProjectSpecificMethods{
	
	public MyHomePage verifyMyHomePage() {
		
		verifyTitle("My Home | opentaps CRM");
		//verifyDisplayed(locateElement(Locators.LINK_TEXT,"Leads"));
		
		reportStep("MyHomepage is matching with expected title", "pass");
		return this;
	}
	
	
	
	
}
