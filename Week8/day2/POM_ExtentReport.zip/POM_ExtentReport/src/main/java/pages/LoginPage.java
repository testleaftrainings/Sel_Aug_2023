package pages;

import java.io.IOException;

import org.openqa.selenium.By;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

public class LoginPage extends BaseClass{ 


	@Given("Enter the username as {string}")
	public LoginPage enterUsername(String uName) throws IOException {
		try {
			getDriver().findElement(By.id("username")).sendKeys(uName);
			reportStep(uName +" is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(e+  " Username is not entered successfully", "fail");
			
		}
		return this;
	}

	@And("Enter the password as {string}")
	public LoginPage enterPassword(String pWord) throws IOException {
		try {
			getDriver().findElement(By.id("password")).sendKeys(pWord);
			reportStep(pWord+ " is entered successfully", "pass");
		} catch (Exception e) {
			reportStep(e+ "Password is not entered successfully", "fail");
		}
		return this;
	}
	
	@When("Click on Login Button")
	public WelcomePage clickLoginButton() throws IOException {
		try {
			getDriver().findElement(By.className("decorativeSubmit")).click();
			reportStep("Login button is clicked successfully", "pass");
		} catch (Exception e) {
			reportStep("Login is not done", "fail");
		}
		return new WelcomePage();

	}

}
