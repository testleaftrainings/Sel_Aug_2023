package utils;

public class GenerateRanNum {
public static void main(String[] args) {
	//img1234434
	//img32632837
	int ranNum=(int)(Math.random()*99999+99999);
	System.out.println(ranNum);
}
}
