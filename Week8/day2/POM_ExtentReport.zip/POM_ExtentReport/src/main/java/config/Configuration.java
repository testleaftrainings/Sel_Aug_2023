package config;

import org.aeonbits.owner.Config;

@Config.Sources("classpath:app.properties")
public interface Configuration extends Config{
	@Key("browser")
	String getBrowser();
	
	

}
