package base;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.DataProvider;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.aventstack.extentreports.reporter.ExtentHtmlReporter;

import config.ConfigurationManager;
import io.cucumber.testng.AbstractTestNGCucumberTests;
import utils.ReadExcel;

public class BaseClass extends AbstractTestNGCucumberTests{
	public String excelFileName;
	public static ExtentReports extent;
	public static ExtentTest test;
	public String testName,testDescription,testCategory,testAuthor;
	private static final ThreadLocal<RemoteWebDriver> rd = new ThreadLocal<RemoteWebDriver>();

	public void setDriver(String browser) {
		if (browser.equalsIgnoreCase("chrome")) {
			rd.set(new ChromeDriver());
		}else if(browser.equalsIgnoreCase("firefox")) {
			rd.set(new FirefoxDriver());
		}else if(browser.equalsIgnoreCase("edge")) {
			rd.set(new EdgeDriver());
		}
		

	}

	public RemoteWebDriver getDriver() {
		return rd.get();

	}

	@BeforeSuite
	public void startReport() {
		ExtentHtmlReporter reporter = new ExtentHtmlReporter("./reports/result.html");
		reporter.setAppendExisting(true);
		extent = new ExtentReports();
		extent.attachReporter(reporter);
	}

	@BeforeClass
	public void testcaseDetails() {
		test = extent.createTest(testName,testDescription);
		test.assignAuthor(testAuthor);
		test.assignCategory(testCategory);

	}
    
	public int takeSnap() throws IOException {
		int ranNum=(int)(Math.random()*99999+99999);
		File src = getDriver().getScreenshotAs(OutputType.FILE);
		File dest = new File("./snaps/img"+ranNum+".png");
		FileUtils.copyFile(src, dest);
        return ranNum;
	}
	
	public void reportStep(String msg,String status) throws IOException {
		if (status.equals("pass")) {
          test.pass(msg);
		}else if(status.equals("fail")) {
			test.fail(msg,MediaEntityBuilder.createScreenCaptureFromPath("../snaps/img"+takeSnap()+".png").build());
			throw new RuntimeException("See report for more details");
		}

	}

	@AfterSuite
	public void stopReport() {
		extent.flush();
	}
    
	@BeforeMethod
	public void preCondition() {
		String browser = ConfigurationManager.configuration().getBrowser();
		setDriver(browser);
		getDriver().manage().window().maximize();
		getDriver().get("http://leaftaps.com/opentaps/control/main");
		getDriver().manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
	}

	@AfterMethod
	public void postCondition() {
		getDriver().quit();

	}

	@DataProvider(name="fetchData",parallel=true)
	public String[][] sendData() throws IOException {
		return ReadExcel.readExcel(excelFileName);

	}

}
