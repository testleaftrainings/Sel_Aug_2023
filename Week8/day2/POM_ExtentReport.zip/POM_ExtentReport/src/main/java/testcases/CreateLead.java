package testcases;

import java.io.IOException;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class CreateLead extends BaseClass{
	
	@BeforeTest
	public void setValues() {
		excelFileName="CreateLead";
		testName="CreateLead";
		testDescription="CreateLead with Dynamic data";
		testAuthor="Subraja";
		testCategory="sanity";
		
	}
	@Test(dataProvider="fetchData")
	public void runCreateLead(String uName,String pWord,String cName,String fName,String lName) throws IOException {
		LoginPage lp = new LoginPage();
		lp.enterUsername(uName)
		.enterPassword(pWord)
		.clickLoginButton()
		.verifyLogin()
		.clickCRMSFALink()
		.clickLeadsLink()
		.clickCreateLeadLink()
		.enterCompanyName(cName)
		.enterFirstName(fName)
		.enterLastName(lName)
		.clickSubmitButton()
		.verifyCreateLad(cName);
	}

}
