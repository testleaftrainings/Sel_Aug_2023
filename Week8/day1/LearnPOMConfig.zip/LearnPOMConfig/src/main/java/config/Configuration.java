package config;

import org.aeonbits.owner.Config;

@Config.Sources("classpath:configfr.properties")
public interface Configuration extends Config{
	
	@Key("timeout")
	int gettimeOut();
	
	@Key("username")
	String getUsername();
	
	@Key("password")
	String getPassword();
	
	@Key("leads")
	String getLeadsLink();
	
	@Key("createLead")
	String getCreateLeadLink();

}
