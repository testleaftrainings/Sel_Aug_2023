package config;

import org.aeonbits.owner.ConfigCache;

public class ConfigurationManager {
	
	public static Configuration configuration() {
		Configuration create = ConfigCache.getOrCreate(Configuration.class);
		return create;
	}

}
