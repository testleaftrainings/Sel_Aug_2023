package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import config.ConfigurationManager;

public class MyLeadsPage extends BaseClass{ 
	public MyLeadsPage(ChromeDriver driver) {
		this.driver=driver;
	}
	public CreateLeadPage clickCreateLeadLink() {
		String createLeadLink = ConfigurationManager.configuration().getCreateLeadLink();
		driver.findElement(By.partialLinkText(createLeadLink)).click();
		return new CreateLeadPage(driver);

	}

}
