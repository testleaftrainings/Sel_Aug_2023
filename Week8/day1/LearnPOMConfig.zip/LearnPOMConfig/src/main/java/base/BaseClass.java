package base;

import java.time.Duration;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import config.ConfigurationManager;




public class BaseClass {
	public  ChromeDriver driver ;
	public String excelFileName;

	@BeforeMethod
	public void preCondition() {
		driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		int timeOut = ConfigurationManager.configuration().gettimeOut();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(timeOut));
	}

	@AfterMethod
	public void postCondition() {
		driver.quit();

	}


}
