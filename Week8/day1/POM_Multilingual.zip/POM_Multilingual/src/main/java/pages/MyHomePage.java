package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class MyHomePage extends BaseClass{ 
	
	public MyHomePage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}
	
	public MyLeadsPage clickLeadsLink() {
		String leadsValue = prop.getProperty("leads");
		driver.findElement(By.xpath(leadsValue)).click();
		return new MyLeadsPage(driver,prop);

	}

}
