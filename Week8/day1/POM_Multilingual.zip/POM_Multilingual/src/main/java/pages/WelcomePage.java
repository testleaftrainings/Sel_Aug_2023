package pages;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;

public class WelcomePage extends BaseClass{ 

	public WelcomePage(ChromeDriver driver,Properties prop) {
		this.driver=driver;
		this.prop=prop;
	}
	
	public WelcomePage verifyLogin() {
		String title = driver.getTitle();
		System.out.println(title);
		return this;
	}
	
	public MyHomePage clickCRMSFALink() {
		driver.findElement(By.partialLinkText("CRM/SFA")).click();
		return new MyHomePage(driver,prop);

	}

}
