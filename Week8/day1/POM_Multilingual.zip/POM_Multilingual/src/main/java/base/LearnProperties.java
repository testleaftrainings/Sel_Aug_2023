package base;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

public class LearnProperties {
	
	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("./src/main/resources/config.properties");
		
		Properties prop = new Properties();
		prop.load(fis);
		
		String value = prop.getProperty("username");
		System.out.println(value);
		
		String passValue = prop.getProperty("password");
		System.out.println(passValue);
		
		ChromeDriver driver= new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://leaftaps.com/opentaps/control/main");
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.findElement(By.id("username")).sendKeys(value);
		driver.findElement(By.id("password")).sendKeys(passValue);
		driver.findElement(By.className("decorativeSubmit")).click();
		
	}

}
