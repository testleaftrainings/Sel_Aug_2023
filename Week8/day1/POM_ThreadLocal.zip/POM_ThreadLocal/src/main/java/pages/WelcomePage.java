package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;

import base.BaseClass;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;

public class WelcomePage extends BaseClass{ 

	@Then("HomePage should be displayed")
	public WelcomePage verifyLogin() {
		String title = getDriver().getTitle();
		System.out.println(title);
		return this;
	}
	@And("Click on crmsfa link")
	public MyHomePage clickCRMSFALink() {
		getDriver().findElement(By.partialLinkText("CRM/SFA")).click();
		return new MyHomePage();

	}

}
