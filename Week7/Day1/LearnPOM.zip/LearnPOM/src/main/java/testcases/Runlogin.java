package testcases;

import org.testng.annotations.Test;

import base.BaseClass;
import pages.LoginPage;

public class Runlogin extends BaseClass{
	
	@Test
	public void runLogin() {
		System.out.println(driver);
		/*
		 * LoginPage lp = new LoginPage(); lp.enterUsername(); lp.enterPassword();
		 * lp.clickLoginButton();
		 * 
		 * WelcomePage wp = new WelcomePage(); wp.clickCRMSFALink();
		 */
		
		LoginPage lp = new LoginPage(driver);
		lp.enterUsername().enterPassword().clickLoginButton().verifyLogin().clickCRMSFALink();
	}

}
