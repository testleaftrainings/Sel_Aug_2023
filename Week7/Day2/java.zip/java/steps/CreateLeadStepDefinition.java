package steps;

import org.openqa.selenium.By;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class CreateLeadStepDefinition extends BaseClass{
	
	
	@When("Click on crmsfa link")
	public void clickcrmsfalink() {
	   driver.findElement(By.partialLinkText("CRM/SFA")).click();
	}

	@When("Click on Leads Link")
	public void clickleadslink() {
		driver.findElement(By.linkText("Leads")).click();
	}

	@When("Click on CreateLead Link")
	public void clickcreateleadlink() {
		driver.findElement(By.linkText("Create Lead")).click();
	}

	@Given("Enter the companyname as (.*)$")
	public void enter_the_companyname(String cName) {
		driver.findElement(By.id("createLeadForm_companyName")).sendKeys(cName);
	}

	@Given("Enter the firstname as (.*)$")
	public void enter_the_firstname(String fName) {
		driver.findElement(By.id("createLeadForm_firstName")).sendKeys(fName);
	}

	@Given("Enter the lastname as (.*)$")
	public void enter_the_lastname(String lName) {
		driver.findElement(By.id("createLeadForm_lastName")).sendKeys(lName);
	}

	@When("Click on submit button")
	public void click_on_submit_button() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Then("ViewLeadsPage should be displayed as (.*)$")
	public void view_leads_page_should_be_displayed(String cName) {
		String text = driver.findElement(By.id("viewLead_companyName_sp")).getText();
		if (text.contains(cName)) {
			System.out.println(cName+  "Lead created successfully");
		}
		else {
			System.out.println("Lead is not created");
		}
	}

	
}
